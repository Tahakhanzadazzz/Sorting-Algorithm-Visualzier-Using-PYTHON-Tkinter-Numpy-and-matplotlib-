# Radix sort in Python
import matplotlib.pyplot as plt
import numpy as np 
import time
def countingSort(arr, exp1):
 
    n = len(arr)
 
    # The output array elements that will have sorted arr
    output = [0] * (n)
 
    # initialize count array as 0
    count = [0] * (10)
 
    # Store count of occurrences in count[]
    for i in range(0, n):
        index = arr[i] // exp1
        count[index % 10] += 1
    for i in range(1, 10):
        count[i] += count[i - 1]
 
    # Build the output array
    i = n - 1
    while i >= 0:
        index = arr[i] // exp1
        output[count[index % 10] - 1] = arr[i]
        count[index % 10] -= 1
        i -= 1

    i = 0
    for i in range(0, len(arr)):
        arr[i] = output[i]
 
# Method to do Radix Sort
def radixSort(arr):
 
    # Find the maximum number to know number of digits
    max1 = max(arr)
    exp = 1
    while max1 / exp >= 1:
        countingSort(arr, exp)
        exp *= 10

def countingSort_medium(array, place):
    x=np.arange(0,10,1)
    size = len(array)
    output = [0] * size
    count = [0] * 10
    # Calculate count of elements
    for i in range(0, size):
        index = array[i] // place
        count[index % 10] += 1

    # Calculate cumulative count
    for i in range(1, 10):
        count[i] += count[i - 1]

    # Place the elements in sorted order
    i = size - 1
    while i >= 0:
        plt.bar(x,count, color="blue")
        plt.xlabel('Sorting elements....')
        plt.pause(1)
        plt.clf()
        index = array[i] // place
        output[count[index % 10] - 1] = array[i]
        count[index % 10] -= 1
        i -= 1

    for i in range(0, size):
        plt.bar(x,count, color="red")
        plt.pause(0.2)
        plt.xlabel('Displaying output')
        plt.clf()
        array[i] = output[i]



# Main function to implement radix sort
def radixSort_medium(array):
    # Get maximum element
    max_element = max(array)

    # Apply counting sort to sort elements based on place value.
    place = 1
    while max_element // place > 0:
        countingSort_medium(array, place)
        place *= 1000

def main():
    amount=1000
    x=np.arange(0,10,1)
    data = np.random.randint(0, 1000,amount)
    with open('medium.txt', 'w') as f:
        for number in data:
            f.write(str(number) + '\n')

    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    array=[]
    for i in range(10):
        array.append(new_list[i])
    n = len(array)

    radixSort_medium(array)
    plt.show()

def timetaken():
    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    
    n=len(new_list)
    start_time = time.time()
    # now sorting the complete array
    radixSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time

