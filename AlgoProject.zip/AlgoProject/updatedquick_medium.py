import matplotlib.pyplot as plt 
import numpy as np
import numpy
import time
import random

def quicksort(arr, k):
    # If the subarray has fewer than k elements, return without sorting it
    if len(arr) < k:
        return

    # Select a pivot element randomly
    pivot = random.choice(arr)

    # Partition the array around the pivot
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]

    # Recursively sort the left and right subarrays
    quicksort(left, k)
    quicksort(right, k)

    # Concatenate the sorted left and right subarrays with the middle subarray
    arr[:] = left + middle + right

def sort(arr, k):
    # First, perform quicksort on the entire array
    quicksort(arr, k)

    # Then, run insertion sort on the entire array to finish the sorting process
    for i in range(1, len(arr)):
        x = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > x:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = x

def quicksort_medium(arr, k):
    m= np.arange(0, len(arr), 1)
    # If the subarray has fewer than k elements, return without sorting it
    if len(arr) < k:
        return

    # Select a pivot element randomly
    pivot = random.choice(arr)

    # Partition the array around the pivot
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    plt.bar(m, arr, color='g')
    plt.pause(0.2)
    plt.clf()

    # Recursively sort the left and right subarrays
    quicksort_medium(left, k)
    quicksort_medium(right, k)

    # Concatenate the sorted left and right subarrays with the middle subarray
    arr[:] = left + middle + right

def sort_medium(arr, k):
    m= np.arange(0, len(arr), 1)
    # First, perform quicksort on the entire array
    quicksort_medium(arr, k)

    # Then, run insertion sort on the entire array to finish the sorting process
    for i in range(1, len(arr)):
        x = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > x:
            plt.bar(m, arr, color=["b" if x != j and x != i else "r" for x in arr])
            plt.pause(0.2)
            plt.clf()
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = x
    plt.bar(m, arr)
    plt.pause(0.2)

# Test the sorting algorithm
# arr = [5, 2, 4, 6, 1, 3]
def main():
    amount = 1000
    lst = np.random.randint(0, 1000, amount)
    x= np.arange(0, 10, 1)
    with open('medium.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    array=[]
    for i in range(10):
        array.append(new_list[i])


    k = 3
    sort_medium(array, k)
    plt.show()

def timetaken():
    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    start_time = time.time()
    k=3
    # now sorting the complete array
    sort(new_list,k)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time


