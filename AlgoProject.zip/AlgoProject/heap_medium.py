import matplotlib.pyplot as plt
import numpy as np
import time


def heapify(arr, n, i):
    largest = i  # Initialize largest as root
    l = 2 * i + 1  # left = 2*i + 1
    r = 2 * i + 2  # right = 2*i + 2

# See if left child of root exists and is
# greater than root

    if l < n and arr[i] < arr[l]:
        largest = l

# See if right child of root exists and is
# greater than root

    if r < n and arr[largest] < arr[r]:
        largest = r

# Change root, if needed

    if largest != i:
        (arr[i], arr[largest]) = (arr[largest], arr[i])  # swap

# Heapify the root.

        heapify(arr, n, largest)


def heapSort(arr):
    N = len(arr)
 
    # Build a maxheap.
    for i in range(N//2 - 1, -1, -1):
        heapify(arr, N, i)
 
    # One by one extract elements
    for i in range(N-1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]  # swap
        heapify(arr, i, 0)

def heapSort_medium(arr):
    n = len(arr)
    for i in range(n // 2 - 1, -1, -1):
        x = np.arange(0, 10, 1)
        plt.bar(x, arr, color='gray')  # set all bars to gray
        plt.bar(x[i], arr[i], color='red')  # set comparing bars to red
        # plt.bar(x[largest], arr[largest], color='red')
        plt.pause(0.001)
        plt.clf()
        heapify(arr, n, i)


    
    for i in range(n - 1, 0, -1):
        x = np.arange(0, 10, 1)
        plt.bar(x, arr, color="red")  # add color parameter
        plt.pause(0.5)
        plt.clf()
        (arr[i], arr[0]) = (arr[0], arr[i])  # swap
        heapify(arr, i, 0)



# Driver code to test above
def main():
    amount = 1000
    lst = np.random.randint(0, 1000, amount)
    x = np.arange(0, 10, 1)
    with open('medium.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    array=[]
    for i in range(10):
        array.append(new_list[i])
    heapSort_medium(array)

    plt.bar(x, array)
    plt.pause(0.001)
    plt.show()

def timetaken():
    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    
    n=len(new_list)
    start_time = time.time()
    # now sorting the complete array
    heapSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time

