import matplotlib.pyplot as plt 
import numpy as np
import numpy
import time

def bubbleSort(arr):
	n = len(arr)
	swapped = False
	# Traverse through all array elements
	for i in range(n-1):

		for j in range(0, n-i-1):
			if arr[j] > arr[j + 1]:
				swapped = True
				arr[j], arr[j + 1] = arr[j + 1], arr[j]


def bubblesort_large(arr):
    x= np.arange(0, 10, 1)
    n = len(arr)
    colors = ["b"] * 10 #create a list of blue colors for each bar
    for i in range(n):
        for j in range(0, n-i-1):
            plt.bar(x, arr, color=colors)
            plt.xlabel("ArrayElements")
            plt.ylabel("Values")
            plt.title("BubbleSort")
            plt.pause(0.001)
            plt.clf()
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                colors[j] = "r"
                colors[j+1] = "r"
    plt.show()


def main():
    amount = 1000000
    lst = np.random.randint(0, 1000000, amount)
    x= np.arange(0, 10, 1)
    with open('large.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('large.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))

    array=[]
    for i in range(10):
        array.append(new_list[i])

    bubblesort_large(array)

def timetaken():
    new_list = []
    with open('large.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    start_time = time.time()
    # now sorting the complete array
    bubbleSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time
