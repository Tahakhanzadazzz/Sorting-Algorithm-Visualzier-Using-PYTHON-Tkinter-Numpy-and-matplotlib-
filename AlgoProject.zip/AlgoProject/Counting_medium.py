# Counting sort in Python programming
import matplotlib.pyplot as plt
import numpy as np
import time 

def countingSort(array):
    size = len(array)
    output = [0] * size
     
    count = [0] * 10

    # Store the count of each elements in count array
    for i in range(0, size):
        count[array[i]] += 1

    # define x as the range of the length of the count array

    # Store the cummulative count
    for i in range(1, 10):
        count[i] += count[i - 1]

    i = size - 1
    while i >= 0:
        output[count[array[i]] - 1] = array[i]
        count[array[i]] -= 1
        i -= 1

    # Copy the sorted elements into original array
    for i in range(0, size):
        array[i] = output[i]
        # Copy the sorted elements into original array
        for i in range(0, size):
            array[i] = output[i]

def countingSort_medium(array):
    x = np.arange(0, 10, 1)
    size = len(array)
    output = [0] * size
     
    count = [0] * 10

    # Store the count of each elements in count array
    for i in range(0, size):
        count[array[i]] += 1
        plt.bar(x,count,color="red")
        plt.pause(0.2)
        plt.clf()

    # define x as the range of the length of the count array

    # Store the cummulative count
    for i in range(1, 10):
        plt.bar(x,count,color="red")
        plt.pause(0.2)
        plt.clf()
        count[i] += count[i - 1]

    # Find the index of each element of the original array in count array
    # place the elements in output array
    i = size - 1
    while i >= 0:
        output[count[array[i]] - 1] = array[i]
        count[array[i]] -= 1
        i -= 1
        plt.bar(x,count,color="blue")
        plt.pause(0.2)
        plt.clf()

    # Copy the sorted elements into original array
    for i in range(0, size):
        array[i] = output[i]
        # Copy the sorted elements into original array
        for i in range(0, size):
            array[i] = output[i]
    plt.bar(x,count,color="red")
    plt.pause(0.2)

def main():
    amount=1000
    x=np.arange(0,10,1)
    lst = np.random.randint(0, 10,amount)
    with open('medium.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    array=[]
    for i in range(10):
        array.append(new_list[i])


    countingSort_medium(array)
    plt.show()

def timetaken():
    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    start_time = time.time()
    # now sorting the complete array
    countingSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time

