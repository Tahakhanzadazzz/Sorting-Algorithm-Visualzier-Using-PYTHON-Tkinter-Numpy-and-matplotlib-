# # # from tkinter import *
# # # from tkinter import ttk
# # # import tkinter as tk
# # # import time
# # # from PIL import ImageTk, Image
# # # from tkinter import messagebox
# # # # from tkinter.ttk import *
# # # import random
# # # import numpy as np
# # #
# # # root = Tk()
# # # root.wm_iconbitmap("icon.ico")
# # # root.geometry("1000x1000")
# # # root.title("Sorting Visualizer")
# # # # frame=Frame(root).pack()
# # # # img = ImageTk.PhotoImage(Image.open("image1.png"))
# # # # label = Label(frame, image = img)
# # # # label.pack()
# # #
# # #
# # # scrollbar = Scrollbar(root)
# # # scrollbar.pack(side=RIGHT, fill=Y)
# # # list = Listbox(root, yscrollcommand=scrollbar.set)
# # # f1 = Frame(root, borderwidth=6, relief=SUNKEN, bg='#082A46')
# # # f1.pack(pady=3, fill="y", padx=12)
# # # l = Label(f1, text="Welcome to Sorting Algorithm Visualizer",
# # #           font="lucida 33 bold", background="grey", relief=GROOVE, bd=5).pack()
# # #
# # # selected_algo = StringVar()
# # # root.config(bg='#082A46')
# # #
# # # f2 = Frame(root, borderwidth=6, relief=SUNKEN, bg='#082A46', pady=20)
# # # # f1.place(x=2,y=10)
# # # f2.pack(pady=3, fill="y", padx=12)
# # # l2 = Label(root, text="Select Algorithm", font="lucida 20 bold italic",
# # #            background="grey", relief=GROOVE, bd=5).pack(pady=45)
# # #
# # # algorithm_name = StringVar()
# # # # algo_list is to select which alforithm we want to use to sort
# # # algo_list = ['Bubble Sort', 'Merge Sort']
# # # speed_name = StringVar()
# # # # speed_list is for selecting sorting speed
# # # speed_list = ['Fast', 'Medium', 'Slow']
# # # progressbar = Frame(root).place(x=220, y=470)
# # # # blank = Frame(progressbar).place(x=0, y=0)
# # # # def load():
# # # Loading_bar = ttk.Progressbar(progressbar, orient=HORIZONTAL,
# # #                                   length=500, mode='determinate')
# # # # Loading_bar.place(x=0, y=0)
# # # def dest():
# # #     root.after(3000, root.destroy)
# # # def run():
# # #     current_value = Loading_bar.cget('value')
# # #     # Loading_bar.place(x=220, y=480)
# # #     if current_value < 100:
# # #         root.after(10, run)
# # #         Loading_bar.config(value=current_value + 1)
# # #     Loading_bar.place(x=220, y=480)
# # #     dest()
# # #     # root.destroy()
# # #     # time.sleep(2)
# # #     # root.destroy()
# # #     # # blank = Frame(progressbar).place(x=0, y=0)
# # #     # Loading_bar.tkraise()
# # #     # Loading_bar.lower()
# # #     # Loading_bar = ttk.Progressbar(progressbar, orient=HORIZONTAL,
# # #     #                               length=500, mode='determinate')
# # #
# # # # blank = Frame(progressbar).place(x=0, y=0)
# # # # Loading_bar.tkraise()
# # # # Loading_bar.lower()
# # #
# # #
# # # # x=x+1
# # #     # Progress_Bar = ttk.Progressbar(root, orient=HORIZONTAL, length=250, mode='determinate')
# # #     # import time
# # #     # # time.sleep(2)
# # #     # Progress_Bar['value'] = 20
# # #     # root.update_idletasks()
# # #     # time.sleep(2)
# # #     # Progress_Bar['value'] = 50
# # #     # root.update_idletasks()
# # #     # time.sleep(2)
# # #     # Progress_Bar['value'] = 80
# # #     # root.update_idletasks()
# # #     # time.sleep(2)
# # #     # Progress_Bar['value'] = 100
# # #     # Progress_Bar.pack()
# # #     # pass
# # #
# # # # This function will draw randomly generated list data[] on the canvas as vertical bars
# # # def set_speed():
# # #     if speed_menu.get() == 'Slow':
# # #         return 0.3
# # #     elif speed_menu.get() == 'Medium':
# # #         return 0.1
# # #     else:
# # #         return 0.001
# # #
# # # # This funciton will trigger a selected algorithm and start sorting
# # #
# # #
# # # def sort():
# # #     # run()
# # #     # global data
# # #     # timeTick = set_speed()
# # #     # Progress_Bar = ttk.Progressbar(root, orient=HORIZONTAL, length=250, mode='determinate')
# # #     # import time
# # #     # Progress_Bar['value'] = 20
# # #     # root.update_idletasks()
# # #     # time.sleep(2)
# # #     # Progress_Bar['value'] = 50
# # #     # root.update_idletasks()
# # #     # time.sleep(2)
# # #     # Progress_Bar['value'] = 80
# # #     # root.update_idletasks()
# # #     # time.sleep(2)
# # #     # Progress_Bar['value'] = 100
# # #     # Progress_Bar.pack()
# # #     # time.sleep(5)
# # #     if algo_menu.get() == 'Bubble Sort':
# # #         from bubbleSort import bubble_sort
# # #         bubble_sort()
# # #
# # #     elif algo_menu.get() == 'Merge Sort':
# # #         # time.sleep(8)
# # #         from mergeSort import main
# # #         main()
# # #
# # #
# # # def exit():
# # #
# # #     # import time
# # #     # time.sleep(2)
# # #     msg_box = tk.messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application?',
# # #                                         icon='warning')
# # #     if msg_box == 'yes':
# # #         run()
# # #         # import time
# # #         # time.sleep(1)
# # #         # root.destroy()
# # #     else:
# # #         tk.messagebox.showinfo(
# # #             'Return', 'You will now return to the application screen')
# # # def on_enter(e):
# # #     b1['background'] = 'green'
# # #
# # # def on_leave(e):
# # #     b1['background'] = 'SystemButtonFace'
# # #
# # #
# # #
# # # UI_frame = Frame(root, width=900, height=300, bg='grey')
# # # UI_frame.pack(padx=10, pady=5)
# # #
# # # # dropdown to select sorting algorithm
# # # l1 = Label(UI_frame, text="Algorithm: ", bg="grey")
# # # l1.pack(padx=10, pady=5)
# # # algo_menu = ttk.Combobox(
# # #     UI_frame, textvariable=algorithm_name, values=algo_list)
# # # algo_menu.pack(padx=5, pady=5)
# # # algo_menu.current(0)
# # #
# # # # dropdown to select sorting speed
# # # l2 = Label(UI_frame, text="Sorting Speed: ", bg="grey")
# # # l2.pack(padx=10, pady=5)
# # # speed_menu = ttk.Combobox(UI_frame, textvariable=speed_name, values=speed_list)
# # # speed_menu.pack(padx=5, pady=5)
# # # speed_menu.current(0)
# # #
# # # # sort button
# # # b1 = Button(root, text="Sort", command=sort, bg="grey",
# # #             font="lucida 14 bold").place(x=490, y=402)
# # #
# # # b2 = Button(root, text="Exit", command=exit, bg="grey", font="lucida 14 bold")
# # # # Loading_bar.place(x=220, y=480)
# # # #b2.pack( padx=5, pady=5)
# # # b2.place(x=430, y=402)
# # #
# # #
# # # # frame=Frame(root,width=900,height=500,bg='grey').pack()
# # # # image = Image.open("image1.png")
# # # #
# # # # # Resize the image using resize() method
# # # # resize_image = image.resize((7,8))
# # # #
# # # # img = ImageTk.PhotoImage(resize_image)
# # # #
# # # # # create label and add resize image
# # # # label1 = Label(image=img)
# # # # label1.image = img
# # # # label1.pack()
# # #
# # # root.mainloop()
# #
# #
# # from tkinter import ttk
# # import tkinter as tk
# #
# # root = tk.Tk()
# # root.title('Full Window Scrolling X Y Scrollbar Example')
# # root.geometry("1350x400")
# #
# # # Create A Main frame
# # main_frame = tk.Frame(root)
# # main_frame.pack(fill=tk.BOTH,expand=1)
# #
# # # Create Frame for X Scrollbar
# # sec = tk.Frame(main_frame)
# # sec.pack(fill=tk.X,side=tk.BOTTOM)
# #
# # # Create A Canvas
# # my_canvas = tk.Canvas(main_frame)
# # my_canvas.pack(side=tk.LEFT,fill=tk.BOTH,expand=1)
# #
# # # Add A Scrollbars to Canvas
# # x_scrollbar = ttk.Scrollbar(sec,orient=tk.HORIZONTAL,command=my_canvas.xview)
# # x_scrollbar.pack(side=tk.BOTTOM,fill=tk.X)
# # y_scrollbar = ttk.Scrollbar(main_frame,orient=tk.VERTICAL,command=my_canvas.yview)
# # y_scrollbar.pack(side=tk.RIGHT,fill=tk.Y)
# #
# # # Configure the canvas
# # my_canvas.configure(xscrollcommand=x_scrollbar.set)
# # my_canvas.configure(yscrollcommand=y_scrollbar.set)
# # my_canvas.bind("<Configure>",lambda e: my_canvas.config(scrollregion= my_canvas.bbox(tk.ALL)))
# #
# # # Create Another Frame INSIDE the Canvas
# # second_frame = tk.Frame(my_canvas)
# #
# # # Add that New Frame a Window In The Canvas
# # my_canvas.create_window((0,0),window= second_frame, anchor="nw")
# #
# # for thing in range(100):
# #     tk.Button(second_frame ,text=f"Button  {thing}").grid(row=5,column=thing,pady=10,padx=10)
# #
# # for thing in range(100):
# #     tk.Button(second_frame ,text=f"Button  {thing}").grid(row=thing,column=5,pady=10,padx=10)
# #
# # root.mainloop()



# # import tkinter as tk
# # from tkinter import ttk
# #
# # root = tk.Tk()
# #
# # combostyle = ttk.Style()
# #
# # combostyle.theme_create('combostyle', parent='alt',
# #                          settings = {'TCombobox':
# #                                      {'configure':
# #                                       {'selectbackground': 'blue',
# #                                        'fieldbackground': 'red',
# #                                        'background': 'green'
# #                                        }}}
# #                          )
# # combostyle.theme_use('combostyle')
# #
# # combo = ttk.Combobox(root, values=['1', '2', '3'])
# # combo['state'] = 'readonly'
# # combo.pack()
# #
# # entry = tk.Entry(root)
# # entry.pack()
# #
# # root.mainloop()

# # from tkinter import *

# # def printSomething():
# #     # if you want the button to disappear:
# #     # button.destroy() or button.pack_forget()
# #     for x in range(9): # 0 is unnecessary
# #         label = Label(root, text= str(x))
# #     # this creates x as a new label to the GUI
# #         label.pack()

# # root = Tk()

# # button = Button(root, text="Print Me", command=printSomething)
# # button.pack()

# # root.mainloop()
# from tkinter import *
# root=Tk() 
# root.geometry('800x800') 
 
# def my_process():  
# #....--do something--  
#     var="I did it" 
#     var1.set(var)  
  
# def my_process2():  
# #....--do something else--  
#     var2="Do process 2"  
#     var1.set(var2)  
  
# var1=StringVar()  
  
# b1=Button(root,text='press', command=my_process) 
# b1.pack() 
# b2=Button(root,text='press2', command=my_process2) 
# b2.pack() 
# l1=Label(root, textvariable=var1) 
# l1.pack() 
# root.mainloop() 

# importing tkinter module
from tkinter import *

# creating Tk() variable
# required by Tkinter classes
master = Tk()

# Tkinter variables
# Giving user defined names to each variables
# so that variables can be modified easily
intvar = IntVar(master, name ="int")
strvar = StringVar(master, name ="str")
boolvar = BooleanVar(master, name ="bool")
doublevar = DoubleVar(master, name ="float")

# Setting values of variables
# using setvar() method
master.setvar(name ="int", value = 100)
master.setvar(name ="str", value ="GFG")
master.setvar(name ="bool", value = False)
master.setvar(name ="float", value = 1.236)

# getting values of each variables using getvar() method
print("Value of IntVar()", master.getvar(name ="int"))
print("Value of StringVar()", master.getvar(name ="str"))
print("Value of BooleanVar()", master.getvar(name ="bool"))
print("Value of DoubleVar()", master.getvar(name ="float"))
