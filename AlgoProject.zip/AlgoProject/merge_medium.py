import matplotlib.pyplot as plt
import numpy as np
import time


def mergeSort(arr):
    if len(arr) > 1:

        # Finding the mid of the array
        mid = len(arr)//2

        # Dividing the array elements
        L = arr[:mid]

        # into 2 halves
        R = arr[mid:]

        # Sorting the first half
        mergeSort(L)

        # Sorting the second half
        mergeSort(R)

        i = j = k = 0

        # Copy data to temp arrays L[] and R[]
        while i < len(L) and j < len(R):
            if L[i] <= R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1

        # Checking if any element was left
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1

        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1


def merge_medium(arr, l, m, r):
    n1 = m - l + 1
    n2 = r - m

    # create temp arrays
    L = [0] * (n1)
    R = [0] * (n2)

    # Copy data to temp arrays L[] and R[]
    for i in range(0, n1):
        L[i] = arr[l + i]

    for j in range(0, n2):
        R[j] = arr[m + 1 + j]

    # Merge the temp arrays back into arr[l..r]
    i = 0	 # Initial index of first subarray
    j = 0	 # Initial index of second subarray
    k = l	 # Initial index of merged subarray

    while i < n1 and j < n2:
        if L[i] <= R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        k += 1

    # Copy the remaining elements of L[], if there
    # are any
    while i < n1:
        arr[k] = L[i]
        i += 1
        k += 1

    # Copy the remaining elements of R[], if there
    # are any
    while j < n2:
        arr[k] = R[j]
        j += 1
        k += 1

# l is for left index and r is right index of the
# sub-array of arr to be sorted


def mergeSort_medium(arr, l, r):
    x = np.arange(0, 10, 1)
    colors = ["b"] * 10
    if l < r:
        # Same as (l+r)//2, but avoids overflow for
        # large l and h
        m = l+(r-l)//2

        colors[l] = "r"
        colors[m] = "r"
        plt.bar(x, arr, color=colors)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("MergeSort")
        plt.pause(0.1)
        plt.clf()

        # Sort first and second halves
        mergeSort_medium(arr, l, m)
        colors[l] = "g"
        colors[m] = "g"
        plt.bar(x, arr, color=colors)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("MergeSort")
        plt.pause(0.1)
        plt.clf()
        mergeSort_medium(arr, m+1, r)

        colors[l] = "b"
        colors[m] = "b"
        plt.bar(x, arr, color=colors)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("MergeSort")
        plt.pause(0.1)
        plt.clf()

        merge_medium(arr, l, m, r)
        plt.bar(x, arr, color=colors)
        plt.xlabel("ArrayElements")
        plt.ylabel("Values")
        plt.title("MergeSort")
        plt.pause(0.5)
        plt.clf()


def main():
    amount = 1000
    lst = np.random.randint(0, 1000, amount)
    x = np.arange(0, 10, 1)
    with open('medium.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))

    array = []
    for i in range(10):
        array.append(new_list[i])

    n = len(array)
    mergeSort_medium(array, 0, n-1)
    plt.show()


def timetaken():
    new_list = []
    with open('medium.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    start_time = time.time()
    # now sorting the complete array
    mergeSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time
main()