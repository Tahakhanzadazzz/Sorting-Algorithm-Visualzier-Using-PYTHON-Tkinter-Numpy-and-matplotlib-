import matplotlib.pyplot as plt 
import numpy as np
import time

def insertionSort(arr):
	for i in range(1, len(arr)):

		key = arr[i]
		j = i-1
		while j >= 0 and key < arr[j] :
				arr[j + 1] = arr[j]
				j -= 1
		arr[j + 1] = key


def insertionSort_small(arr):
    x = np.arange(0, 10, 1)
    # Traverse through 1 to len(arr)
    for i in range(1, len(arr)):
        # Set the color of the bars based on the values being compared
        bar_colors = ['blue'] * len(arr)  # Set the default color to blue
        bar_colors[i] = 'orange'  # Set the color of the current value to orange
        bar_colors[i-1] = 'red'  # Set the color of the previous value to red

        # Plot the bars using the specified colors
        plt.bar(x, arr, color=bar_colors)
        plt.pause(0.2)
        plt.clf()
        
        key = arr[i]
        j = i-1
        while j >= 0 and key < arr[j] :
            arr[j + 1] = arr[j]
            j -= 1
            arr[j + 1] = key
        plt.bar(x, arr, color=bar_colors)
        plt.pause(0.2)
        plt.clf()
    plt.bar(x,arr)
    plt.pause(1)
    plt.show()


def main():
    amount = 10
    lst = np.random.randint(0, 100, amount)
    x = np.arange(0, 10, 1)
    with open('small.txt', 'w') as f:
        for number in lst:
            f.write(str(number) + '\n')

    new_list = []
    with open('small.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    array=[]
    for i in range(10):
        array.append(new_list[i])

    insertionSort_small(array)

def timetaken():
    new_list = []
    with open('small.txt', 'r') as f:
        for line in f:
            new_list.append(int(line))
    start_time = time.time()
    # now sorting the complete array
    insertionSort(new_list)

    end_time = time.time()
    total_time = end_time-start_time
    print(total_time)
    return total_time